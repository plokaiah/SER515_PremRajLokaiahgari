// Reminder pattern is implemented here in Reminder.java

public class Reminder {
    private String reminder;

    public Reminder(String reminder) {
        this.reminder = reminder;
    }
//method to get the reminder
    public String getReminder() {
        return reminder;
    }
//method to set the reminder
    public void setReminder(String reminder) {
        this.reminder = reminder;
    }
}

