public interface ListIterator {

    boolean hasNext();
    Object next();
    void moveToHead();
    void remove();
}
