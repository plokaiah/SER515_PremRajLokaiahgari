public interface ProductMenu {
    void showMenu();
    void showAddButton();
    void showViewButton();
    void showRadioButton();
    void showLabels();
    void showComboxes();
}
