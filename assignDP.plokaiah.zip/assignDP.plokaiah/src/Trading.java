public class Trading {

    public void accept(NodeVisitor visitor){

    }
}
