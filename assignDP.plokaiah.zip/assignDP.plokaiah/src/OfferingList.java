import java.util.ArrayList;

public class OfferingList extends ArrayList {
}
