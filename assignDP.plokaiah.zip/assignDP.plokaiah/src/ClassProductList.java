import java.util.ArrayList;

public class ClassProductList extends ArrayList<Product> {

    public void accept(NodeVisitor visitor){

    }
}
